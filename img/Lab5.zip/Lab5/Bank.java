public class Bank {
    public static void main(String[] args) throws Exception {
        Account a =new Account();
        a.SetAcc_no("981232234V");
        a.SetName("Nimal Jayasinghe");
        a.SetId("981232234V");
        a.SetEmail("nimalj@gmail.com");
        a.SetAmount(25000.0);

        System.out.println("Account Number\t\t\t\t\t :"+a.GetAcc_no());
        System.out.println("Name of the account holder\t\t :"+a.GetName());
        System.out.println("ID of the account holder\t\t :"+a.GetId());
        System.out.println("E-mail of the account holder\t :"+a.GetEmail());
        System.out.println("Total amount deposited\t\t\t :"+a.GetAmount());

    }
}
