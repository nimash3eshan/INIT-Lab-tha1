public class Account {
    private String acc_no;
    private String name ;
    private String email;
    private String id;
    private  double amount;

    public void SetAcc_no(String acc_no) throws Exception{
        if (acc_no!=null){
            this.acc_no=acc_no;}
        else{
            throw new Exception("Invalid Account Number");
        }
    }

    public void SetAmount(double amount){
        if (amount>=0)
        this.amount=amount;
        else
            System.out.println("Amount is INVALID");
    }

    public void SetName(String name){
        this.name=name;
    }

    public void SetEmail(String email){
        this.email=email;
    }

    public void SetId(String id){
        this.id=id;
    }

    // get

    public String GetAcc_no(){
        return acc_no;
    }

    public String GetName(){
        return name;
    }

    public String GetId(){
        return id;
    }

    public String GetEmail(){
        return email;
    }

    public double GetAmount(){
        return amount;
    }

}
