public class Tablet extends Laptop{
    void typesOfTablet(){
        System.out.println("There are different tablets named as Convertible tablets, hybrid tablets and rugged tablets");
    }
}
