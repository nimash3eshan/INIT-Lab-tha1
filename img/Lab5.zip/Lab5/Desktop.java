public class Desktop extends PC{
    void typesOfDesktop(){
        System.out.println("Desktop computers fall into three main families named as Tower, Compact and All-in-one");
    }
}
