public class Test {
    public static void main(String[] args) {
//        Desktop d=new Desktop();
//        d.typesOfPC();
//        d.typesOfDesktop();

//        Laptop l=new Laptop();
//        l.typesOfLaptop();
            Tablet t =new Tablet();
            t.typesOfLaptop();
            t.typesOfTablet();
            t.typesOfPC();

    }
}
