public class Laptop extends PC{
    void typesOfLaptop(){
        System.out.println("There are different Laptops named as Notebook, Macbook, Ultrabook, Tablet etc.");
    }
}
