public class PC {
    int k;
    void typesOfPC(){
        System.out.println("There are two different personal computers named as Desktops and Laptops");
    }
}
